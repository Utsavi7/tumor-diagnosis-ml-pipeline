# Breast Cancer Diagnosis Classifier

An end-to-end machine learning project that predicts whether a breast tumor is **malignant or benign**
from 30 cell-nucleus measurements (Wisconsin Diagnostic Breast Cancer dataset, 569 samples).

## What it does
- Compares Logistic Regression, SVM and Random Forest using stratified 5-fold cross-validation
- Tunes the best model with `GridSearchCV` (scored by ROC-AUC)
- Evaluates once on a held-out 20% test set (no data leakage: scaling lives inside the pipeline)
- Generates a confusion matrix, ROC curve and permutation feature importance
- Saves the trained model and provides a CLI for predictions

## Run
```bash
pip install -r requirements.txt
python train.py      # trains, evaluates, saves everything to ./outputs
python predict.py    # predicts random samples with the saved model
```

## Results
See `outputs/metrics.json` after training (typically ~97-98% accuracy and ~0.99+ ROC-AUC).

## Tech
Python, scikit-learn, pandas, NumPy, Matplotlib, joblib

## Note
Educational project, not a medical device.
