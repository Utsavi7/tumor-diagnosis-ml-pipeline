"""Predict diagnosis for a sample.

Run:  python predict.py            -> predicts 3 random samples from the dataset
      python predict.py --index 10 -> predicts dataset row 10
"""
import argparse
from pathlib import Path

import joblib
from sklearn.datasets import load_breast_cancer

MODEL_PATH = Path(__file__).parent / "outputs" / "best_model.joblib"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=int, help="row index of the dataset to predict")
    args = parser.parse_args()

    if not MODEL_PATH.exists():
        raise SystemExit("Model not found. Run `python train.py` first.")
    bundle = joblib.load(MODEL_PATH)
    model, names = bundle["model"], bundle["target_names"]

    X, y = load_breast_cancer(return_X_y=True, as_frame=True)
    rows = [args.index] if args.index is not None else X.sample(3, random_state=None).index.tolist()
    for i in rows:
        sample = X.loc[[i]]
        p = model.predict_proba(sample)[0]
        label = names[int(p.argmax())]
        print(f"Row {i}: predicted = {label} ({p.max():.1%} confidence) | actual = {names[y.loc[i]]}")


if __name__ == "__main__":
    main()
