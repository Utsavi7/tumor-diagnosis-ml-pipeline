"""Train, compare, tune and evaluate models for breast cancer diagnosis.

Run:  python train.py
Outputs (in ./outputs): best_model.joblib, metrics.json, confusion_matrix.png,
roc_curve.png, feature_importance.png, model_comparison.csv
"""
import json
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (ConfusionMatrixDisplay, RocCurveDisplay,
                             accuracy_score, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import (GridSearchCV, StratifiedKFold,
                                     cross_val_score, train_test_split)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

SEED = 42
OUT = Path(__file__).parent / "outputs"
OUT.mkdir(exist_ok=True)


def main():
    # 1. Data -----------------------------------------------------------
    data = load_breast_cancer(as_frame=True)
    X, y = data.data, data.target  # target: 0 = malignant, 1 = benign
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=SEED)
    print(f"Samples: {len(X)} | Features: {X.shape[1]} | "
          f"Train/Test: {len(X_train)}/{len(X_test)}")

    # 2. Compare baseline models with 5-fold CV -------------------------
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    candidates = {
        "Logistic Regression": Pipeline([("scale", StandardScaler()),
                                         ("clf", LogisticRegression(max_iter=5000))]),
        "SVM (RBF)": Pipeline([("scale", StandardScaler()),
                               ("clf", SVC(probability=True, random_state=SEED))]),
        "Random Forest": Pipeline([("clf", RandomForestClassifier(
            n_estimators=200, random_state=SEED))]),
    }
    rows = []
    for name, pipe in candidates.items():
        scores = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="roc_auc")
        rows.append({"model": name, "cv_auc_mean": scores.mean(), "cv_auc_std": scores.std()})
        print(f"{name:20s} CV AUC = {scores.mean():.4f} +/- {scores.std():.4f}")
    comparison = pd.DataFrame(rows).sort_values("cv_auc_mean", ascending=False)
    comparison.to_csv(OUT / "model_comparison.csv", index=False)

    # 3. Tune the best model type with grid search ----------------------
    best_name = comparison.iloc[0]["model"]
    grids = {
        "Logistic Regression": {"clf__C": [0.01, 0.1, 1, 10, 100]},
        "SVM (RBF)": {"clf__C": [0.1, 1, 10, 100], "clf__gamma": ["scale", 0.01, 0.001]},
        "Random Forest": {"clf__n_estimators": [100, 300], "clf__max_depth": [None, 5, 10]},
    }
    search = GridSearchCV(candidates[best_name], grids[best_name], cv=cv,
                          scoring="roc_auc", n_jobs=-1)
    search.fit(X_train, y_train)
    model = search.best_estimator_
    print(f"\nBest model: {best_name} | params: {search.best_params_} | "
          f"tuned CV AUC = {search.best_score_:.4f}")

    # 4. Final evaluation on held-out test set --------------------------
    pred = model.predict(X_test)
    proba = model.predict_proba(X_test)[:, 1]
    metrics = {
        "model": best_name,
        "best_params": {k: (v if isinstance(v, (int, float, str, type(None))) else str(v))
                        for k, v in search.best_params_.items()},
        "accuracy": accuracy_score(y_test, pred),
        "precision": precision_score(y_test, pred),
        "recall": recall_score(y_test, pred),
        "f1": f1_score(y_test, pred),
        "roc_auc": roc_auc_score(y_test, proba),
    }
    print("\nTest set results:")
    for k in ["accuracy", "precision", "recall", "f1", "roc_auc"]:
        print(f"  {k:10s}: {metrics[k]:.4f}")
    (OUT / "metrics.json").write_text(json.dumps(metrics, indent=2))

    # 5. Plots ----------------------------------------------------------
    ConfusionMatrixDisplay.from_predictions(
        y_test, pred, display_labels=data.target_names, cmap="Blues")
    plt.title("Confusion Matrix (test set)")
    plt.tight_layout(); plt.savefig(OUT / "confusion_matrix.png", dpi=150); plt.close()

    RocCurveDisplay.from_predictions(y_test, proba, name=best_name)
    plt.plot([0, 1], [0, 1], "k--", alpha=0.4)
    plt.title("ROC Curve (test set)")
    plt.tight_layout(); plt.savefig(OUT / "roc_curve.png", dpi=150); plt.close()

    imp = permutation_importance(model, X_test, y_test, n_repeats=20,
                                 random_state=SEED, scoring="roc_auc")
    top = pd.Series(imp.importances_mean, index=X.columns).nlargest(10)[::-1]
    top.plot.barh(color="steelblue", figsize=(8, 5))
    plt.xlabel("Permutation importance (drop in AUC)")
    plt.title("Top 10 Most Important Features")
    plt.tight_layout(); plt.savefig(OUT / "feature_importance.png", dpi=150); plt.close()

    # 6. Save model -----------------------------------------------------
    joblib.dump({"model": model, "features": list(X.columns),
                 "target_names": list(data.target_names)}, OUT / "best_model.joblib")
    print(f"\nSaved model and reports to: {OUT}")


if __name__ == "__main__":
    main()
